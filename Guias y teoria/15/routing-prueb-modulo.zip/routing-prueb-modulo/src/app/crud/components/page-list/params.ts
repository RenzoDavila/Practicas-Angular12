export class Params {

  public q: string;
  public page: string;

  constructor() { 
    this.q = '';
    this.page = '';
  }

}
