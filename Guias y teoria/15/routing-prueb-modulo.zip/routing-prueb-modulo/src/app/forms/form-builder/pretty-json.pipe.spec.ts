/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PrettyJsonPipe } from './pretty-json.pipe';

describe('Pipe: PrettyJsone', () => {
  it('create an instance', () => {
    let pipe = new PrettyJsonPipe();
    expect(pipe).toBeTruthy();
  });
});
