export class Song {
  link: string;
  top: string;
  artist: string;
  title: string;

  constructor() {
    this.link = '';
    this.top = '';
    this.artist = '';
    this.title = '';

  }

}
