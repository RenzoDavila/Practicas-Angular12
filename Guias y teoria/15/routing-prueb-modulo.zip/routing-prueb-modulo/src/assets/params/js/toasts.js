var myToastEl = document.getElementById('myToast')
myToastEl.classList.add("show");
